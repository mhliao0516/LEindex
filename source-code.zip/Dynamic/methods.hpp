#include "graph.hpp"
#include <stack>
#include <Eigen/Dense>
#include <Eigen/QR>

class Solver {
public:
    virtual int init() = 0;
    virtual double single_pair_resistance_query(int u, int v) = 0;
    virtual void add_edge_update(int u, int v) = 0;
    virtual void del_edge_update(int u, int v) = 0;
    virtual size_t getMemoryUsage() = 0;
};

class RwIdx {
public:
    vector<vector<int>> rw_tr;
    vector<unordered_map<int,int>> hit;

    RwIdx(Graph &graph, vector<int> &terminal_map) {
        idx_build_by_random_walk(graph, terminal_map);
    }

    void idx_build_by_random_walk(Graph &graph, vector<int>& terminal_map) {
        int n = graph.n, cur;
        rw_tr.resize(n + 1);
        hit.resize(n + 1);

        vector<vector<int>> &G = graph.adj;

        for (int i = 1; i <= n; i++) {

            hit[i].insert({i, 0}); 
            
            if (terminal_map[i] != -1) continue;

            vector<int> &tr = rw_tr[i];
            
            int cur = i;

            do {
                cur = G[cur][rand() % G[cur].size()];
                
                tr.push_back(cur);

                hit[cur].insert({i, tr.size()});
            
            } while (terminal_map[cur] == -1);
            // cout << i  << endl;
        }
        return;
    }

    size_t getMemoryUsage() {
        size_t res = 0;
        
        res += sizeof(rw_tr);
        for (auto &vec : rw_tr) {
            res += sizeof(vec) + vec.size() * sizeof(int);
        }

        res += sizeof(hit);
        for (auto &map : hit) {
            res += map.size() * sizeof(int) + sizeof(void*);
            res += map.bucket_count() * (sizeof(void*) + sizeof(size_t));
        }
        return res;
    }

};

class RwSol : public Solver {
public: 
    // Graph
    Graph &graph;
    int n;
    // Index Size T
    int T; 
    double eps; 
    // bipush params
    int T_bp;
    double rmax;   
    // Schur Complement
    Eigen::MatrixXd schur;
    Eigen::MatrixXd schur_pinv;
    bool is_schur_update, is_schur_pinv_update;
    // Landmarks
    vector<int> terminals, tml_map;
    // Index
    vector<RwIdx> rw_idxs;

// Init
    RwSol(Graph &graph, const vector<int> &tmls, double eps) : graph(graph) {
        this->n = graph.n;
        this->eps = eps;
        is_schur_update = false;
        is_schur_pinv_update = false;
        set_terminals(tmls);
    }

    RwSol(Graph &graph, const vector<int> &tmls, double eps, double rmax, int T_bp) : graph(graph) {
        this->n = graph.n;
        this->eps = eps;
        this->rmax = rmax;
        this->T_bp = T_bp; 
        is_schur_update = false;
        is_schur_pinv_update = false;
        set_terminals(tmls);
    }
    // Building initial Index
    int init() {
        T = log(n) / eps / eps; 
        cout << "Idx Size: " << T << endl;
        idx_build(T);
        return T;
    }

    void idx_build(int N) {
        rw_idxs.clear();
        for (int i = 0; i < N; i++) {
            if (i % (N / 10) == 0) cout << "idx build " << i << endl;
            rw_idxs.emplace_back(graph, tml_map);
        }
        return;
    }
    // Landmarks Operations
    void set_terminals(const vector<int> &tmls) {
        terminals = tmls;
        tml_map = vector<int> (n + 1, -1);
        for (int i = 0; i < tmls.size(); i++) {
            tml_map[tmls[i]] = i;
        }
        return;
    }
    
    bool is_terminal(int x) {
        return tml_map[x] != -1;
    }

    bool add_terminal(int tml) {
        if (is_terminal(tml)) {
            printf("%d is already a terminal vertex\n", tml);
            return false;
        }
        terminals.push_back(tml);
        tml_map[tml] = terminals.size() - 1;
        
        return true;
    }

    bool del_terminal(int tml) {
        if (!is_terminal(tml)) {
            printf("%d is not a terminal vertex\n", tml);
            return false;
        }

        if (terminals.back() == tml) {
            terminals.pop_back();
            tml_map[tml] = -1;
            return true;
        }

        int del_pos = tml_map[tml];
        terminals.erase(terminals.begin() + del_pos);
        tml_map[tml] = -1;
        // reorder tml_map
        for (int i = del_pos; i < terminals.size(); i++) {
            int tml = terminals[i];
            tml_map[tml] = i;
        }

        return true;
    }

    void read_terminals(string filename) {
        FILE *fin = fopen(filename.c_str(), "r");
        int t;
        vector<int> tmls;
        while (fscanf(fin, "%d", &t) != EOF) 
            tmls.push_back(t);

        set_terminals(tmls);
        return;
    }

// Update 
    // Update Index : Add (Del) Termianls    
    void idx_update_add_terminal(RwIdx &idx, int t) {
        for (auto [st, pos] : idx.hit[t]) {
            for (int i = pos; i < idx.rw_tr[st].size(); i++) {
                int v = idx.rw_tr[st][i];
                
                auto it = idx.hit[v].find(st);
                if (it == idx.hit[v].end() || (*it).second <= pos) {
                    continue;
                } else {
                    idx.hit[v].erase(it);
                }
            }
            idx.rw_tr[st] = vector<int>(idx.rw_tr[st].begin(), idx.rw_tr[st].begin() + pos);
        }

        return;
    }

    void idx_update_add_terminal(int t) {
        if (!add_terminal(t)) return;

        for (int i = 0; i < rw_idxs.size(); i++) {
            RwIdx &idx = rw_idxs[i];
            idx_update_add_terminal(idx, t);
        }

        is_schur_update = false;
        is_schur_pinv_update = false;

        return;
    }

    void idx_update_del_terminal(RwIdx &idx, int t) {
        vector<vector<int>> &G = graph.adj;
        for (auto it = idx.hit[t].begin(); it != idx.hit[t].end(); it++) {
            int st = (*it).first, pos = (*it).second, cur = t;
            if (pos != idx.rw_tr[st].size()) 
                cout << "error" << endl;
            vector<int> &tr = idx.rw_tr[st];

            do {
                cur = G[cur][rand() % G[cur].size()];

                tr.push_back(cur);
                idx.hit[cur].insert({st, tr.size()});

            } while(!is_terminal(cur));
        }

        return;
    }

    void idx_update_del_terminal(int t) {
        if (!del_terminal(t)) return;

        for (int i = 0; i < rw_idxs.size(); i++) {
            RwIdx &idx = rw_idxs[i];
            idx_update_del_terminal(idx, t);
        } 
        is_schur_update = false;
        is_schur_pinv_update = false;
    }

    // Update Index when adding(removing) edge
    void add_edge_update(int u, int v) {
        if (!graph.add_edge(u, v)) {
            // add edge fail
            return;
        }
        bool is_tml_u = is_terminal(u), is_tml_v = is_terminal(v);
        
        if (is_tml_u && is_tml_v) {
            // u, v are terminals
            if (is_schur_update) {
                // if u & v are already in V_l, add 1 on weight(u, v) in schur graph
                schur(tml_map[u], tml_map[v]) += 1.;
                schur(tml_map[v], tml_map[u]) += 1.;
            }
        } else {
            // if not, add vertex into terminals set
            if (!is_tml_u) idx_update_add_terminal(u);
            if (!is_tml_v) idx_update_add_terminal(v);
            // after adding u(v) into terminals set, remove u(v) out to maintain a fix size of T
            if (!is_tml_v) idx_update_del_terminal(v);
            if (!is_tml_u) idx_update_del_terminal(u);
        }

        return;
    }

    void del_edge_update(int u, int v) {
        if (!graph.del_edge(u, v)) {
            //del edge fail
            return;
        }
        bool is_tml_u = is_terminal(u), is_tml_v = is_terminal(v);
        if (is_tml_u && is_tml_v) {
            // u, v are terminals
            if (is_schur_update) {
                // if u & v are already in V_l, add 1 on weight(u, v) is ok without recompute schur complement
                schur(tml_map[u], tml_map[v]) -= 1.;
                schur(tml_map[v], tml_map[u]) -= 1.;
            }
        } else {
            // if not, add vertex into terminals set
            if (!is_tml_u) idx_update_add_terminal(u);
            if (!is_tml_v) idx_update_add_terminal(v);
            // after adding u(v) into terminals set, remove u(v) out to maintain a fix size of T
            if (!is_tml_v) idx_update_del_terminal(v);
            if (!is_tml_u) idx_update_del_terminal(u);
        }

        return;
    }

// Query
    // Compute Schur Complement
    Eigen::MatrixXd Laplacian(const Eigen::MatrixXd& adj) {
        int n = adj.rows();
        Eigen::MatrixXd lap(n, n);
        Eigen::VectorXd deg = adj * Eigen::VectorXd::Ones(n);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j)     lap(i, j) = deg(i) - adj(i, j);
                //else if (i < j) lap(i, j) = lap(j, i);
                //else if (i > j) lap(i, j) = - adj(i, j);
                else lap(i, j) = - min(adj(i, j), adj(j, i));
            }
        }

        return lap;
    }

    void compute_schur() {
        vector<vector<int>> &G = graph.adj;
        int N = rw_idxs.size(), l = terminals.size();
        double inc = 1. / N;

        schur.resize(l, l);
        schur.setZero();
        
        for (int i = 0; i < terminals.size(); i++) {
            int &t1 = terminals[i];
            for (int ne : G[t1]) {
                if (tml_map[ne] != -1) {
                    // ne 是terminal
                    schur(i, tml_map[ne]) += 1.;
                    continue;
                }
                for (int j = 0; j < N; j++) {
                    int hit_tml = rw_idxs[j].rw_tr[ne].back();
                    schur(i,tml_map[hit_tml]) += inc;
                }
            }
        }
        is_schur_update = true;
        return;
    }

    void compute_schur_pinv() {
        if(!is_schur_update) compute_schur();
        Eigen::MatrixXd lap = Laplacian(schur);
        // SVD
        Eigen::JacobiSVD<Eigen::MatrixXd> svd(lap, Eigen::ComputeThinU | Eigen::ComputeThinV);
        Eigen::VectorXd sgl_val = svd.singularValues();
        Eigen::MatrixXd sgl_val_inv = sgl_val.asDiagonal();
        // singular inv
        for (int i = 0; i < sgl_val.size(); i++) {
            if (sgl_val(i) > 1e-12)
                sgl_val_inv(i, i) = 1. / sgl_val(i);
            else
                sgl_val_inv(i, i) = 0;
        }

        schur_pinv = svd.matrixV() * sgl_val_inv * svd.matrixU().transpose();
        is_schur_pinv_update = true;
        
        return;
    }

    Eigen::VectorXd get_hit_prob(int x) {
        // return a V_l vector with the probability of x rooted by each landmarks
        assert(!is_terminal(x));    // x should not be terminal

        int tml_size = terminals.size(), N = rw_idxs.size(); assert(N);
        double inc = 1. / (double) N;

        Eigen::VectorXd prob = Eigen::VectorXd::Zero(tml_size);
        
        for (int i = 0; i < N; i++) {
            RwIdx& idx = rw_idxs[i];
            int tml = idx.rw_tr[x].back();
            prob(tml_map[tml]) += inc;
        }

        return prob;
    }
        // Bipush
    double bipush_v_absorbed_random_walk(int s, vector<double> &r_s, vector<double> &r_t) {
        double res = 0.;
        if (T_bp == 0) return res;
        vector<vector<int>> &G = graph.adj;
        for (int i = 0; i < T_bp; i++) {
            for (int cur = s; !is_terminal(cur); cur = G[cur][rand() % G[cur].size()]) {
                res += (r_s[cur] - r_t[cur]) / (double) G[cur].size();
            }
        }
        
        res = res / (double) T_bp;
        
        return res;
    }

    void bipush_v_absorbed_push(int s, vector<double> &r_s, vector<double> &X_s) {
        int n = graph.n;
        vector<vector<int>> &G = graph.adj;
        vector<bool> inQueue (n + 1, false);
        queue<int> q;

        r_s[s] = 1.;
        q.push(s);
        inQueue[s] = true;
        // push
        while (!q.empty()) {
            int cur = q.front();
            q.pop();
            inQueue[cur] = false;

            X_s[cur] += r_s[cur];
            
            double inc = r_s[cur] / (double) G[cur].size();
            for (int ne : G[cur]) {
                if (is_terminal(ne)) continue;

                r_s[ne] += inc;

                if (!inQueue[ne] && r_s[ne] > rmax * G[ne].size()) {
                    q.push(ne);
                    inQueue[ne] = true;
                }
            }

            r_s[cur] = 0.;
        }

        return;
    }

    double LUU_resistance_query_bipush(int s, int t) {
        int n = graph.n;
        vector<vector<int>> &G = graph.adj;

        vector<double> X_s(n + 1, 0.), X_t(n + 1, 0.);
        vector<double> R_s(n + 1, 0.), R_t(n + 1, 0.);
        
        double res = 0.;
        if (s == t || (is_terminal(s) && is_terminal(t))) return res;   // return 0.
        if (is_terminal(s)) {
            // r(v, t) = (L_v^-1)tt
            bipush_v_absorbed_push(t, R_t, X_t);
            res += X_t[t] / (double) G[t].size();
            res += bipush_v_absorbed_random_walk(t, R_t, R_s);
        } else if (is_terminal(t)) {
            // r(s, v) = (L_v^-1)ss
            bipush_v_absorbed_push(s, R_s, X_s);
            res += X_s[s] / (double) G[s].size();
            res += bipush_v_absorbed_random_walk(s, R_s, R_t);
        } else {
            // r(s, t)
            bipush_v_absorbed_push(s, R_s, X_s);
            bipush_v_absorbed_push(t, R_t, X_t);
            res += (X_s[s] - X_t[s]) / (double) G[s].size() + (X_t[t] - X_s[t]) / (double) G[t].size();

            res += bipush_v_absorbed_random_walk(s, R_s, R_t);
            res += bipush_v_absorbed_random_walk(t, R_t, R_s);
        }
        return res;
    }
        // Query Resistance Disatance by Bipush+Schur Complement
    double single_pair_resistance_query(int s, int t) {
        bool is_tml_s = is_terminal(s), is_tml_t = is_terminal(t);
        int tml_size = terminals.size();
        double res = 0.;
        Eigen::VectorXd vec_LV_pinv = Eigen::VectorXd::Zero(tml_size);

        if(!is_schur_pinv_update) compute_schur_pinv();
        
        res += LUU_resistance_query_bipush(s, t);

        if (is_tml_s) {
            vec_LV_pinv(tml_map[s]) += 1;
        } else {
            vec_LV_pinv += get_hit_prob(s);
        }
        
        if (is_tml_t) {
            vec_LV_pinv(tml_map[t]) += -1;
        } else {
            vec_LV_pinv -= get_hit_prob(t);
        }

        res += vec_LV_pinv.transpose() * schur_pinv * vec_LV_pinv;
        return res;
    }

// Compute Space Consumption
    size_t getMemoryUsage() {
        size_t res = 0;
        res += sizeof(terminals) + terminals.size() * sizeof(int);
        res += sizeof(terminals) + tml_map.size() * sizeof(int);
        res += sizeof(rw_idxs);
        for (auto &idx : rw_idxs) {
            res += idx.getMemoryUsage();
        }
        res += sizeof(schur) + sizeof(double) * schur.rows() *schur.cols();
        res += sizeof(schur_pinv) + sizeof(double) * schur_pinv.rows() * schur_pinv.cols();
        return res;
    }
};

class StIdx {
public:
    int n;
    bool is_changed_root;
    vector<int> next;
    vector<vector<int>> tree;

    StIdx(Graph& graph, int pivot) {
        this->n = graph.n;
        sample_ust(graph, pivot);
        is_changed_root = true;
    }

    StIdx(Graph& graph, int pivot, int u, int v) {
        this->n = graph.n;
        sample_ust_with_uv(graph, pivot, u, v);
        is_changed_root = false;
    }

    void sample_ust(Graph &graph, int pivot) {
        vector<vector<int>> &G = graph.adj;

        next = vector<int>(n + 1, 0);
        vector<bool> intree(n + 1, false);

        int visit_cnt = 1, cur;
        intree[pivot] = true;

        for (int i = 1; i <= n; i++) {
            for (cur = i; !intree[cur]; cur = next[cur]) {
                next[cur] = G[cur][rand() % G[cur].size()];
            }
            for (cur = i; !intree[cur]; cur = next[cur]) {
                intree[cur] = true;

                visit_cnt++;
            }

            if (visit_cnt == n) break;
        }
        
        return;
    }

    void sample_ust_with_uv(Graph& graph, int pivot, int u, int v) {
        vector<vector<int>> &G = graph.adj;
        vector<bool> intree(n + 1, false);
        next = vector<int>(n + 1, 0);
        tree = vector<vector<int>>(n + 1);

        int visit_cnt = 2, cur;
        intree[u] = true, intree[v] = true;
        tree[u].push_back(v);
        tree[v].push_back(u);

        for (int i = 1; i <= n; i++) {
            for (cur = i; !intree[cur]; cur = next[cur]) {
                next[cur] = G[cur][rand() % G[cur].size()];
            }
            for (cur = i; !intree[cur]; cur = next[cur]) {
                intree[cur] = true;
                
                tree[cur].push_back(next[cur]);
                tree[next[cur]].push_back(cur);

                visit_cnt++;
            }

            if (visit_cnt == n) break;
        }

        return;
    }

    void change_root(int pivot) {
        // Change the root of spanning tree to pivot node (for those USTs with (u, v))
        queue<int> q; 
        vector<bool> visited(n + 1, false);
        int visit_cnt = 1;

        q.push(pivot);
        visited[pivot] = true;
        next[pivot] = 0;

        while(!q.empty()) {
            int cur = q.front();
            q.pop();

            for (int ne : tree[cur]) {
                if (!visited[ne]) {
                    visited[ne] = true;
                    q.push(ne);
                    next[ne] = cur;
                    
                    visit_cnt ++;
                }
            }
            if (visit_cnt == n) break;
        }

        is_changed_root = true;
        vector<vector<int>>().swap(tree);
        return;
    }

    size_t getMemoryUsage() {
        size_t res = 0;
        res += sizeof(next) + next.size() * sizeof(int);
        return res;
    }
};

class StSol : public Solver {
public:
    // Graph
    Graph &graph;
    int n;
    // Index Size
    int T;  
    double eps, delta;
    // single landmark
    int pivot;
    // Index
    vector<StIdx> sp_idxs;
    // bfs tree
    vector<int> bfs_next, depth;
// Init
    StSol(Graph &graph, int pivot, double eps, double delta = 1) : graph(graph) {
        this->n = graph.n;
        this->pivot = pivot;
        this->eps = eps;
        this->delta = delta;
    }

    int init() {
        T = delta * log(n) / eps / eps;
        sp_idxs.reserve(T);
        cout << "Idx Size: " << T << endl;
        idx_build(T);
        return T;
    }

    void idx_build(int N) {
        build_bfs_tree(pivot);
        sp_idxs.clear();
        for (int i = 0; i < N; i++) {
            if (i % 10 == 0) cout << "idx build :" << i << endl;
            sp_idxs.emplace_back(graph, pivot);
        }
    }

    void build_bfs_tree(int root) {
        int n = graph.n;
        vector<vector<int>> &G = graph.adj;
        vector<bool> visit(n+1,false);
        queue<int> q;

        bfs_next = vector<int>(n + 1, 0), depth = vector<int>(n + 1, 0);

        q.push(root);
        depth[root] = 0, visit[root] = true;

        while (!q.empty()) {
            int v = q.front();
            q.pop();

            for (int ne : G[v]) {
                if (!visit[ne]) {
                    q.push(ne);
                    visit[ne] = true;
                    depth[ne] = depth[v] + 1;
                    bfs_next[ne] = v;
                }
            }
        }

        return;
    }
    
    void find_path_by_bfs_tree(int u, int v, vector<int> &path) {
        int pu = u, pv = v;
        path = vector<int>(n + 1, 0);

        while (pu != pv) {
            if (depth[pu] >= depth[pv]) {
                path[pu] = bfs_next[pu];
                pu = bfs_next[pu];
            }
            else {
                path[bfs_next[pv]] = pv;
                pv = bfs_next[pv];
            }
        }

        return;
    }

    bool is_element_in_vector(vector<int> &vec, int val) {
        return find(vec.begin(), vec.end(), val) != vec.end();
    }

    double single_pair_resistance_query(int u, int v) {
        int n = graph.n, N = sp_idxs.size(), cur;
        double res = 0.;
        
        if (u == v) return res;

        vector<int> path;
        find_path_by_bfs_tree(u, v, path);

        for (int i = 0; i < N; i++) {
            StIdx &idx = sp_idxs[i];
            if (idx.next[pivot] != 0) {
                idx.change_root(pivot);
            }
            for (cur = u; cur != pivot; cur = idx.next[cur]) {
                if (path[cur] == idx.next[cur]) {
                    res += 1.;
                }else if (path[idx.next[cur]] == cur) {
                    res -= 1.;
                }
            }
            for (cur = v; cur != pivot; cur = idx.next[cur]) {
                if (path[cur] == idx.next[cur]) {
                    res -= 1.;
                }else if (path[idx.next[cur]] == cur) {
                    res += 1.;
                }
            }
        }

        res = res / (double) N;

        return res;
    }

    void add_edge_update(int u, int v) {
        double r_uv, omega;
        int N, N_new;
        if (!graph.add_edge(u, v)) {
            return;
        }

        // compute omega
        r_uv = single_pair_resistance_query(u, v);
        omega = r_uv / (1. + r_uv);

        N = sp_idxs.size(); assert(N);
        N_new = omega * N;

        // randomly choose w element
        vector<int> randoms(N);
        default_random_engine eng;
        iota(randoms.begin(), randoms.end(), 0);
        shuffle(randoms.begin(), randoms.end(), eng);
        // Regenerate w*N idx with edge (u,v)
        for (int i = 0; i < N_new; i++) {
            sp_idxs[randoms[i]] = StIdx(graph, pivot, u, v);
        }
        // cout << "Change Tree Nums: " << N_new << ", prop: " << (double) omega << endl;

        return;
    }

    void del_edge_update(int u, int v) {
        int N = sp_idxs.size(), cnt = 0;
        if (!graph.del_edge(u, v)) {
            return;
        }
        if (bfs_next[u] == v || bfs_next[v] == u) {
            // Regenerate Bfs Tree
            build_bfs_tree(pivot);
        }

        for (int i = 0; i < sp_idxs.size(); i++) {
            StIdx &idx = sp_idxs[i];
            if ((idx.is_changed_root && (idx.next[u] == v || idx.next[v] == u)) 
                || (!idx.is_changed_root && is_element_in_vector(idx.tree[u], v))) {
                sp_idxs[i] = StIdx(graph, pivot);
                cnt++;
            }
        }
        // cout << "Change Tree Nums: " << cnt << ", prop: " << (double) cnt / N << endl;
    }

    size_t getMemoryUsage() {
        size_t res = 0;
        res += sizeof(bfs_next) + bfs_next.size() * sizeof(int);
        res += sizeof(depth) + depth.size() * sizeof(int);

        res += sizeof(sp_idxs);
        for (auto &idx : sp_idxs) {
            res += idx.getMemoryUsage();
        }
        return res;
    }
};

struct loop {
    int next, nx_pos;
    ll lp_id;
    
    loop(int ne, int np, ll id) {
        next = ne, nx_pos = np, lp_id = id;
    }
};

class LeIdx {
public:
    int n;
    ll id_max;
    vector<vector<loop>> stack;
    vector<int> next, root; 

    vector<vector<int>> forest; // reverse edge of spanning forest in "next" vector

    LeIdx (Graph &graph, vector<int> &terminals) {
        this->n = graph.n;
        id_max = 0;
        
        idx_build_by_lewalk(graph, terminals);
    }

    void idx_build_by_lewalk(Graph &graph, vector<int> &terminals) {
        int n = graph.n, cur, visit_cnt = terminals.size(), seen_cnt = 1;
        vector<vector<int>> &G = graph.adj;

        stack.resize(n + 1), forest.resize(n + 1);
        next = vector<int> (n + 1, 0), root = vector<int> (n + 1, 0);

        vector<bool> intree(n + 1, false);
        vector<int> seen(n+1, 0);
        // printf("Start Building Index...\n");

        for (int i: terminals) {
            intree[i] = true;
            root[i] = i;
        }

        for (int i = 1; i <= n; i++) {
            if (intree[i]) continue;

            for (cur = i; !intree[cur]; cur = next[cur]) {
                if (seen[cur]) {
                    ll id = id_max++;
                    seen_cnt = seen[cur];
                    int finder = next[cur];
                    // next[cur] -> ... -> cur
                    do {
                        seen[finder] = 0;
                        int &ne = next[finder];
                        stack[finder].emplace_back(ne, stack[ne].size(), id);

                        finder = ne;
                    } while (finder != next[cur]);
                    stack[cur].back().nx_pos--; // Make Cycle
                }
                seen[cur] = seen_cnt++;
                next[cur] = G[cur][rand() % G[cur].size()];
            }
            int rt = root[cur];

            for (cur = i; !intree[cur]; cur = next[cur]) {
                intree[cur] = true;

                root[cur] = rt;
                forest[next[cur]].push_back(cur);
                visit_cnt++;
            }

            if (visit_cnt == n) break;
        }
        
        return;
    }

    size_t getMemoryUsage() {
        size_t res = 0;

        res += sizeof(stack);
        for (auto &v : stack) {
            res += sizeof(v) + (v.size() * sizeof(loop));
        }

        res += sizeof(next) + (next.size() * sizeof(int));
        res += sizeof(root) + (root.size() * sizeof(int));
        
        return res;
    }

    bool del_edge_in_forest(int u, int v) {
        // Del directed edge (u, v)
        auto it = find(forest[u].begin(), forest[u].end(), v);
        if (it == forest[u].end()) {
            cout << "err" << endl;
            return false;
        }
        forest[u].erase(it);
        return true;
    }

    void change_root_by_forest(int x, int rt, vector<bool> &vis) {
        queue<int> q;
        q.push(x);
        vis[x] = true;

        while (!q.empty()) {
            int cur = q.front();
            q.pop();
            root[cur] = rt;

            for (int ne : forest[cur]) {
                if (!vis[ne]) {
                    q.push(ne);
                    vis[ne] = true;
                }
            }
        }
        return;
    }
};

class LeSol : public Solver {

public:
    // Graph
    int n;
    Graph &graph;
    // Sample Size
    int T;
    double eps;
    // Bipush Params
    int T_bp;
    double rmax;
    // Schur Complement
    Eigen::MatrixXd schur, schur_pinv;
    bool is_schur_update, is_schur_pinv_update;
    // landmarks
    vector<int> terminals, tml_map;
    // Index
    vector<LeIdx> le_idxs;


    LeSol(Graph &graph, const vector<int> &tmls, double eps, double rmax = 1e-4, int T_bp = 100) : graph(graph) {
        this->n = graph.n;
        this->eps = eps;
        this->rmax = rmax, this->T_bp = T_bp;
        is_schur_update = false;
        is_schur_pinv_update = false;
        set_terminals(tmls);
    }

    int init() {
        T = log(n) / eps / eps;
        cout << "Idx Size: " << T << endl;
        cout << "r_max: " << rmax << ", T(Bipush): " << T_bp << endl;
        idx_build(T);
        return T;
    }
    
    void idx_build(int N) {
        le_idxs.clear();
        for (int i = 0; i < N; i++) {
            if (i % 10 == 0) cout << "idx build " << i << endl;
            le_idxs.emplace_back(graph, terminals);
        }
        return;
    }
    // landmarks init / update
    void set_terminals(const vector<int> &tmls) {
        terminals = tmls;
        tml_map = vector<int> (n+1, -1);
        for (int i = 0; i < tmls.size(); i++) {
            tml_map[tmls[i]] = i;
        }
        return;
    }

    bool del_terminal(int t) {
        if (!is_terminal(t)) {
            printf("%d is not a terminals\n", t);
            return false;
        }

        if (t == terminals.back()) {    // t is the last terminal
            terminals.pop_back();
            tml_map[t] = -1;
            return true;
        }

        int del_pos = tml_map[t];
        terminals.erase(terminals.begin() + del_pos);
        tml_map[t] = -1;
        // reorder tml_map
        for (int i = del_pos; i < terminals.size(); i++) {
            int tml = terminals[i];
            tml_map[tml] = i;
        }

        return true;
    }

    bool add_termianl(int t) {
        if (tml_map[t] != -1) {
            printf("%d is already a terminals\n", t);
            return false;
        }

        tml_map[t] = terminals.size();
        terminals.push_back(t);
        
        return true;
    }

    void read_terminals(string filename) {
        FILE *fin = fopen(filename.c_str(), "r");
        int t;
        vector<int> tmls;
        while (fscanf(fin, "%d", &t) != EOF) 
            tmls.push_back(t);

        set_terminals(tmls);
        return;
    }

    bool is_terminal(int x) {
        return tml_map[x] != -1;
    }

// Query
    // Schur Complement
    void compute_schur() {
        vector<vector<int>> &G = graph.adj;
        int N = le_idxs.size(), l = terminals.size();
        double inc = 1. / N;

        schur.resize(l, l);
        schur.setZero();
        
        for (int i = 0; i < terminals.size(); i++) {
            int &t1 = terminals[i];
            for (int ne : G[t1]) {
                if (tml_map[ne] != -1) {
                    // if ne is a terminal
                    schur(i, tml_map[ne]) += 1.;
                    continue;
                }
                for (int j = 0; j < N; j++) {
                    int hit_tml = le_idxs[j].root[ne];
                    schur(i,tml_map[hit_tml]) += inc;
                }
            }
        }
        is_schur_update = true;
        return;
    }

    void compute_schur_pinv() {
        if(!is_schur_update) compute_schur();
        Eigen::MatrixXd lap = Laplacian(schur);
        // SVD
        Eigen::JacobiSVD<Eigen::MatrixXd> svd(lap, Eigen::ComputeThinU | Eigen::ComputeThinV);
        Eigen::VectorXd sgl_val = svd.singularValues();
        Eigen::MatrixXd sgl_val_inv = sgl_val.asDiagonal();
        // singular inv
        for (int i = 0; i < sgl_val.size(); i++) {
            if (sgl_val(i) > 1e-12)
                sgl_val_inv(i, i) = 1. / sgl_val(i);
            else
                sgl_val_inv(i, i) = 0;
        }
        
        schur_pinv = svd.matrixV() * sgl_val_inv * svd.matrixU().transpose();
        is_schur_pinv_update = true;
        return;
    }

    Eigen::MatrixXd Laplacian(const Eigen::MatrixXd& adj) {
        int n = adj.rows();
        Eigen::MatrixXd lap(n, n);
        Eigen::VectorXd deg = adj * Eigen::VectorXd::Ones(n);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j)     lap(i, j) = deg(i) - adj(i, j);
                else lap(i, j) = - min(adj(i, j), adj(j, i));
            }
        }

        return lap;
    }

    Eigen::VectorXd get_hit_prob(int x) {
        assert(!is_terminal(x));    // x should not be terminal

        int tml_size = terminals.size(); assert(T);
        double inc = 1. / (double) T;

        Eigen::VectorXd prob = Eigen::VectorXd::Zero(tml_size);
        
        for (int i = 0; i < T; i++) {
            int tml = le_idxs[i].root[x];
            prob(tml_map[tml]) += inc;
        }

        return prob;
    }
    // Bipush
    double bipush_v_absorbed_random_walk(int s, vector<double> &r_s, vector<double> &r_t) {
        double res = 0.;
        if (T_bp == 0) return res;
        vector<vector<int>> &G = graph.adj;
        for (int i = 0; i < T_bp; i++) {
            for (int cur = s; !is_terminal(cur); cur = G[cur][rand() % G[cur].size()]) {
                res += (r_s[cur] - r_t[cur]) / (double) G[cur].size();
            }
        }
        
        res = res / (double) T_bp;
        
        return res;
    }

    void bipush_v_absorbed_push(int s, vector<double> &r_s, vector<double> &X_s) {
        vector<vector<int>> &G = graph.adj;
        int n = graph.n;
        // init
        vector<bool> inQueue (n + 1, false);
        queue<int> q;

        r_s[s] = 1.;
        q.push(s);
        inQueue[s] = true;
        // push
        while (!q.empty()) {
            int cur = q.front();
            q.pop();
            inQueue[cur] = false;

            X_s[cur] += r_s[cur];
            
            double inc = r_s[cur] / (double) G[cur].size();
            for (int ne : G[cur]) {
                if (is_terminal(ne)) continue;

                r_s[ne] += inc;

                if (!inQueue[ne] && r_s[ne] > rmax * G[ne].size()) {
                    q.push(ne);
                    inQueue[ne] = true;
                }
            }

            r_s[cur] = 0.;
        }

        return;
    }

    double LUU_resistance_query_bipush(int s, int t) {
        int n = graph.n;
        vector<vector<int>> &G = graph.adj;

        vector<double> X_s(n + 1, 0.), X_t(n + 1, 0.);
        vector<double> R_s(n + 1, 0.), R_t(n + 1, 0.);
        
        double res = 0.;
        if (s == t || (is_terminal(s) && is_terminal(t))) return res;
        if (is_terminal(s)) {
            // r(v, t) = (L_v^-1)tt
            bipush_v_absorbed_push(t, R_t, X_t);
            res += X_t[t] / (double) G[t].size();
            res += bipush_v_absorbed_random_walk(t, R_t, R_s);
        } else if (is_terminal(t)) {
            // r(s, v) = (L_v^-1)ss
            bipush_v_absorbed_push(s, R_s, X_s);
            res += X_s[s] / (double) G[s].size();
            res += bipush_v_absorbed_random_walk(s, R_s, R_t);
        } else {
            // r(s, t)
            bipush_v_absorbed_push(s, R_s, X_s);
            bipush_v_absorbed_push(t, R_t, X_t);
            res += (X_s[s] - X_t[s]) / (double) G[s].size() + (X_t[t] - X_s[t]) / (double) G[t].size();

            res += bipush_v_absorbed_random_walk(s, R_s, R_t);
            res += bipush_v_absorbed_random_walk(t, R_t, R_s);
        }
        // cout << "Bipush LUU: " << res << endl;
        return res;
    }

    double single_pair_resistance_query(int s, int t) {
        bool is_tml_s = is_terminal(s), is_tml_t = is_terminal(t);
        int tml_size = terminals.size();
        double res = 0.;
        Eigen::VectorXd vec_LV_pinv = Eigen::VectorXd::Zero(tml_size);

        if(!is_schur_pinv_update) compute_schur_pinv();
        
        res += LUU_resistance_query_bipush(s, t);

        if (is_tml_s) {
            vec_LV_pinv(tml_map[s]) += 1;
        } else {
            vec_LV_pinv += get_hit_prob(s);
        }
        
        if (is_tml_t) {
            vec_LV_pinv(tml_map[t]) += -1;
        } else {
            vec_LV_pinv -= get_hit_prob(t);
        }

        res += vec_LV_pinv.transpose() * schur_pinv * vec_LV_pinv;
        return res;
    }

// Update
    void idx_update_add_terminal(LeIdx &idx, int t) {
        idx.del_edge_in_forest(idx.next[t], t);
        idx.next[t] = 0, idx.root[t] = t;
        
        if (idx.stack[t].size() != 0) {
            vector<vector<int>> &G = graph.adj;

            vector<int> st_size(n + 1, -1);
            queue<loop> queue_lp;
            unordered_set<ll> visit;
            unordered_set<int> changed_nodes;

            queue_lp.push(idx.stack[t][0]);
            changed_nodes.insert(t), visit.insert(idx.stack[t][0].lp_id);
            st_size[t] = 0;

            while (!queue_lp.empty()) {
                loop lp = queue_lp.front();
                queue_lp.pop();

                int cur = lp.next, cur_pos = lp.nx_pos;
                do {
                    loop nx_lp = idx.stack[cur][cur_pos];
                    int nx = nx_lp.next, nx_pos = nx_lp.nx_pos;

                    if (st_size[cur] == -1 || cur_pos < st_size[cur]) {
                        st_size[cur] = cur_pos;

                        idx.del_edge_in_forest(idx.next[cur], cur);
                        idx.next[cur] = nx;
                        idx.forest[nx].push_back(cur);
                        
                        changed_nodes.insert(cur);
                    }
                    // Add new loop above current loop in queue
                    if (cur_pos < idx.stack[cur].size() - 1) {
                        loop high_lp = idx.stack[cur][cur_pos + 1];

                        bool ins_succ = visit.emplace(high_lp.lp_id).second;
                        if (ins_succ) {
                            queue_lp.push(high_lp);
                        }
                    }
                    // cout << cur << ", " << nx << ", " << lp.next << endl;
                    cur = nx, cur_pos = nx_pos;
                } while (cur != lp.next);
            }
        
            for (int node : changed_nodes) {
                idx.stack[node] = vector<loop> (idx.stack[node].begin(), idx.stack[node].begin() + st_size[node]);
            }
        }
        
        vector<bool> root_changed(n + 1, false);
        idx.change_root_by_forest(t, t, root_changed);

        return;
    }
    
    void idx_update_add_terminal(int t) {
        if (!add_termianl(t)) return;

        for (int i = 0; i < le_idxs.size(); i++) {
            idx_update_add_terminal(le_idxs[i], t);
        }

        is_schur_update = false, is_schur_pinv_update = false;
        return;
    }
    
    void idx_update_del_terminal(LeIdx &idx, int t) {
        int seen_cnt = 1;
        vector<vector<int>>& G = graph.adj;
        vector<int> &next = idx.next, root_changed_nodes, seen(n+1, 0);
        vector<bool> intree(n+1, true);
        queue<int> out_tree_nodes;
        
        intree[t] = false;
        out_tree_nodes.push(t);

        while (!out_tree_nodes.empty()) {
            int tml = out_tree_nodes.front(), cur;
            out_tree_nodes.pop();
            if (intree[tml]) continue;

            for (cur = tml; idx.root[cur] == t; cur = next[cur]) {
                // find loop
                if (seen[cur]) {
                    ll id = idx.id_max++;
                    seen_cnt = seen[cur];
                    // Loop Trace: cur -> xxx
                    int finder = next[cur];
                    do {
                        seen[finder] = 0;
                        int ne = next[finder];
                        idx.stack[finder].emplace_back(ne, idx.stack[ne].size(), id);
                        // vertex in cycle outtree
                        if(intree[finder]) {
                            intree[finder] = false;
                            idx.del_edge_in_forest(next[finder], finder);
                            out_tree_nodes.push(finder);
                        }
                        finder = ne;
                    } while (finder != next[cur]);
                    idx.stack[cur].back().nx_pos--; // Make Cycle
                }
                seen[cur] = seen_cnt++;
                if (!intree[cur])
                    next[cur] = G[cur][rand() % G[cur].size()];
            }
            int rt = idx.root[cur];
            // cur intree
            for (cur = tml; idx.root[cur] == t; cur = next[cur]) {
                idx.root[cur] = rt;

                if (!intree[cur]) {
                    idx.forest[next[cur]].push_back(cur);
                    intree[cur] = true;
                }
            }
            root_changed_nodes.push_back(cur);
        }

        vector<bool> root_changed(n + 1, false);
        for (int v : root_changed_nodes) {
            idx.change_root_by_forest(v, idx.root[v], root_changed);
        }

        return;
    }

    void idx_update_del_terminal(int t) {
        if (!del_terminal(t)) return;
        
        for (int i = 0; i < le_idxs.size(); i++) {
            idx_update_del_terminal(le_idxs[i], t);
        }
        
        is_schur_update = false, is_schur_pinv_update = false;
        return;
    }

    void add_edge_update(int u, int v) {
        if (!graph.add_edge(u, v)) {
            return;
        }
        bool is_tml_u = is_terminal(u), is_tml_v = is_terminal(v);
        // both u, v are landmarks
        if (is_tml_u && is_tml_v) {
            if (is_schur_update) {
                // if u & v are already in V_l, add 1 on weight(u, v) in schur graph
                schur(tml_map[u], tml_map[v]) += 1.;
                schur(tml_map[v], tml_map[u]) += 1.;
            }
        }
        else {
            // if not, add vertex into landmarks set
            if (!is_tml_u) idx_update_add_terminal(u);
            if (!is_tml_v) idx_update_add_terminal(v);
            // remove new landmarks
            if (!is_tml_v) idx_update_del_terminal(v);
            if (!is_tml_u) idx_update_del_terminal(u);
        }
        
        return;
    }

    void del_edge_update(int u, int v) {
        if (!graph.del_edge(u, v)) {
            return;
        }

        bool is_tml_u = is_terminal(u), is_tml_v = is_terminal(v);

        if (is_tml_u && is_tml_v) {
            if (is_schur_update) {
                // if u & v are already in V_l, add -1 on weight(u, v) in schur graph
                schur(tml_map[u], tml_map[v]) -= 1.;
                schur(tml_map[v], tml_map[u]) -= 1.;
            }
        }
        else {
            if (!is_tml_u) idx_update_add_terminal(u);
            if (!is_tml_v) idx_update_add_terminal(v);
            
            if (!is_tml_v) idx_update_del_terminal(v);
            if (!is_tml_u) idx_update_del_terminal(u);
        }
        
        return;
    }

// Compute Time Complexity
    int compute_change_num_add_terminal(LeIdx &idx, int t, int &loop_cnt, int &ele_cnt) {
        
        if (idx.stack[t].size() != 0) {
            vector<vector<int>> &G = graph.adj;

            vector<int> st_size(n + 1, -1);
            queue<loop> queue_lp;
            unordered_set<ll> visit;
            unordered_set<int> changed_nodes;

            queue_lp.push(idx.stack[t][0]);
            changed_nodes.insert(t), visit.insert(idx.stack[t][0].lp_id);
            st_size[t] = 0;

            while (!queue_lp.empty()) {
                loop lp = queue_lp.front();
                queue_lp.pop();

                int cur = lp.next, cur_pos = lp.nx_pos;
                do {
                    loop nx_lp = idx.stack[cur][cur_pos];
                    int nx = nx_lp.next, nx_pos = nx_lp.nx_pos;

                    if (st_size[cur] == -1 || cur_pos < st_size[cur]) {
                        st_size[cur] = cur_pos;

                        changed_nodes.insert(cur);
                    }
                    if (cur_pos < idx.stack[cur].size() - 1) {
                        loop high_lp = idx.stack[cur][cur_pos + 1];

                        bool ins_succ = visit.emplace(high_lp.lp_id).second;
                        if (ins_succ) {
                            queue_lp.push(high_lp);
                        }
                    }
                    // cout << cur << ", " << nx << ", " << lp.next << endl;
                    cur = nx, cur_pos = nx_pos;
                } while (cur != lp.next);
            }
        
            for (int node : changed_nodes) {
                ele_cnt += idx.stack[node].size() - st_size[node];
            }
            loop_cnt = visit.size();
        }
        
        return ele_cnt;
    }

    void compute_time_complexity(ofstream &log_add, int t_siz = 0) {
        double add_time_cplx = 0.;
        int cnt = 0;
        // randomly choose t_siz vertex
        vector<int> randoms(n);
        default_random_engine eng;
        iota(randoms.begin(), randoms.end(), 0);
        shuffle(randoms.begin(), randoms.end(), eng);
        if (t_siz <= 0) t_siz = (n - terminals.size());

        for (int i = 1; i <= n; i++) {
            int tml = randoms[i];
            if (cnt == t_siz) break;
            if (is_terminal(tml)) continue;
            

            int loop_cnt = 0, ele_cnt = 0;
            for (int j = 0; j < T; j++) {
                LeIdx &idx = le_idxs[j];
                compute_change_num_add_terminal(idx, i, loop_cnt, ele_cnt);
            }
            if (log_add.is_open()) log_add << "Tml: " << i << ", Loop Size: " << (double) loop_cnt / T << ", Element Siz: " << (double) ele_cnt /  T << endl;  
            add_time_cplx += (double) ele_cnt / T;
            cnt++;
        }
        cout << "Add Time Complexity: " << (double) add_time_cplx / t_siz << endl;
        if (log_add.is_open()) log_add << "Add Time Complexity: " << (double) add_time_cplx / t_siz << endl;
    }

    ll simple_wilson() {
        int n = graph.n, cur, visit_cnt = terminals.size();
        ll cnt = 0;
        vector<vector<int>> &G = graph.adj;
        vector<int> next(n + 1, 0);

        vector<bool> intree(n + 1, false);
        vector<int> seen(n+1, 0);
        // printf("Start Building Index...\n");

        for (int i: terminals) {
            intree[i] = true;
        }

        for (int i = 1; i <= n; i++) {
            if (intree[i]) continue;

            for (cur = i; !intree[cur]; cur = next[cur]) {
                next[cur] = G[cur][rand() % G[cur].size()];
                cnt++;
            }

            for (cur = i; !intree[cur]; cur = next[cur]) {
                intree[cur] = true;
                visit_cnt++;
            }
            if (visit_cnt == n) break;
        }
        
        return cnt;
    }

    double compute_building_time_complexity(int t_siz = 0) {
        ll total = 0;
        for (int i = 0; i < t_siz; i++) {
            total += simple_wilson();
        }
        cout << "Average Building Time Complexity: " << (double) total / t_siz << endl;
        return (double) total / t_siz;
    }

// Compute Space Consumption
    size_t getMemoryUsage() {
        size_t res = 0;
        res += sizeof(terminals) + terminals.size() * sizeof(int);
        res += sizeof(tml_map) + tml_map.size() * sizeof(int);
        res += sizeof(le_idxs);
        for (int i = 0; i < le_idxs.size(); i++) {
            res += le_idxs[i].getMemoryUsage();
        }
        res += sizeof(schur) + sizeof(double) * schur.rows() *schur.cols();
        res += sizeof(schur_pinv) + sizeof(double) * schur_pinv.rows() * schur_pinv.cols();
        return res;
    }
};

// Compute RWIndex Time Complexity without storing
class RWTimeComplexity {
public:
    Graph &graph;
    int n, T;
    double eps;
    
    vector<int> terminals, tml_map;
    vector<int> new_tmls;
    vector<vector<int>> idxs;

    RWTimeComplexity(Graph &graph, const vector<int> &tmls, double eps) : graph(graph) {
        this->n = graph.n;
        this->eps = eps;
        set_terminals(tmls);
    }

    void set_terminals(const vector<int> &tmls) {
        terminals = tmls;
        tml_map = vector<int> (n+1, -1);
        for (int i = 0; i < tmls.size(); i++) {
            tml_map[tmls[i]] = i;
        }
        return;
    }

    bool is_terminal(int x) {
        return tml_map[x] != -1;
    }

    void init(int t_siz) {
        T = log(n) / eps / eps;
        cout << "Idx Size: " << T << endl;
        // randomly choose w element
        vector<int> randoms(n);
        default_random_engine eng;
        iota(randoms.begin(), randoms.end(), 1);
        shuffle(randoms.begin(), randoms.end(), eng);
        if (t_siz <= 0) t_siz = (n - terminals.size());
        
        for (int i = 1; i <= n; i++) {
            if (is_terminal(i)) continue;
            new_tmls.push_back(randoms[i]);
            if (new_tmls.size() == t_siz) break;
        }
        return;
    }

    double estimate_time_complexity(int v, int sample_siz = 100) {
        double res = 0.;
        vector<vector<int>> &G = graph.adj;

        for (int i = 0; i < sample_siz; i++) {

            int node = rand() % n + 1;
            while (is_terminal(node)) {
                node = rand() % n + 1;
            }
            // invoke T times v-absorbed random walk
            int del_len = 0;
            for (int i = 0; i < T; i++) {
                int hit_v = -1, hit_lm = 0;
                for (int cur = node; !is_terminal(cur); cur = G[cur][rand()%G[cur].size()]) {
                    if (cur == v && hit_v == -1) hit_v = hit_lm;
                    hit_lm++;
                }
                if (hit_v != -1)
                    del_len += hit_lm - hit_v;
            }
            res += (double) del_len / T;
            // cout << node << ": " << (double)del_len / T << endl;
        }

        res = res / sample_siz * (n - terminals.size());

        return res;
    }

    void compute_time_complexity(ofstream &log_add) {
        double add_time_cplx = 0., ele_del;
        int t_siz = new_tmls.size();

        for (int i = 0; i < t_siz; i++) {
            if (i % 100 == 0) cout << "compute " << i << " tmls, " << (double) add_time_cplx / i << endl;
            int v = new_tmls[i];
            ele_del = estimate_time_complexity(v);
            if (log_add.is_open()) log_add << "Tml: " << v << ", Element Siz: " << ele_del << endl;  
            add_time_cplx += ele_del;
        }


        cout << "Add Time Complexity: " << (double) add_time_cplx / t_siz << endl;
        if (log_add.is_open()) log_add << "Add Time Complexity: " << (double) add_time_cplx / t_siz << endl;
    }

    double compute_build_time_complexity(int tcb_siz = 100) {
        vector<int> randoms(n);
        default_random_engine eng;
        iota(randoms.begin(), randoms.end(), 1);
        shuffle(randoms.begin(), randoms.end(), eng);
        if (tcb_siz <= 0) tcb_siz = (n - terminals.size());


        vector<vector<int>> &G = graph.adj;
        int cnt = 0;
        double res = 0.;
        for (int i = 0; i < n; i++) {
            int v = randoms[i];
            if (is_terminal(v)) continue;
            ll rw_cnt = 0;
            for (int j = 0; j < 10; j++) {
                for (int cur = v; !is_terminal(cur); cur = G[cur][rand() % G[cur].size()]) {
                    rw_cnt++;
                }
            }
            res += (double) rw_cnt / 10;
            // cout << res << endl;
            if (++cnt == tcb_siz) break;
        }

        cout << "Average Building Time Complexity of Random Walk: " << res / tcb_siz * (n - terminals.size()) << endl;
        return res / tcb_siz * (n - terminals.size());
    }
};

// Ground Truth
class Bipush : public Solver {
public:
    Graph &graph;
    double r_max;
    int T;
    int landmark;

    Bipush(Graph& graph, int landmark, double r_max = 1e-6, int T = 1000000) : graph(graph) {
        this->r_max = r_max;
        this->T = T;
        this->landmark = landmark;
    }

    int init() {
        cout << "r_max : " << r_max << endl;
        cout << "T : " << T << endl;
        return 0;
    }

    double bipush_v_absorbed_random_walk(int s, vector<double> &r_s, vector<double> &r_t) {
        double res = 0.;
        vector<vector<int>> &G = graph.adj;
        
        for (int i = 0; i < T; i++) {
            for (int cur = s; cur != landmark; cur = G[cur][rand() % G[cur].size()]) {
                res += (r_s[cur] - r_t[cur]) / (double) G[cur].size();
            }
        }
        
        res = res / (double) T;
        
        return res;
    }

    void bipush_v_absorbed_push(int s, vector<double> &r_s, vector<double> &X_s) {
        vector<vector<int>> &G = graph.adj;
        int n = graph.n;
        // init
        vector<bool> inQueue (n + 1, false);
        queue<int> q;

        r_s[s] = 1.;
        q.push(s);
        inQueue[s] = true;
        // push
        while (!q.empty()) {
            int cur = q.front();
            q.pop();
            inQueue[cur] = false;

            X_s[cur] += r_s[cur];
            
            double inc = r_s[cur] / (double) G[cur].size();
            for (int ne : G[cur]) {
                if (ne == landmark) continue;

                r_s[ne] += inc;

                if (!inQueue[ne] && r_s[ne] > r_max * G[ne].size()) {
                    q.push(ne);
                    inQueue[ne] = true;
                }
            }

            r_s[cur] = 0.;
        }

        return;
    }

    void add_edge_update(int u, int v) {
        graph.add_edge(u, v);
    }

    void del_edge_update(int u, int v) {
        graph.del_edge(u, v);
    }

    double single_pair_resistance_query(int s, int t) {
        int n = graph.n;
        vector<vector<int>> &G = graph.adj;

        vector<double> X_s(n + 1, 0.), X_t(n + 1, 0.);
        vector<double> R_s(n + 1, 0.), R_t(n + 1, 0.);
        
        double res = 0.;
        if (s == t) return res;

        if (s == landmark) {
            // r(v, t) = (L_v^-1)tt
            bipush_v_absorbed_push(t, R_t, X_t);
            res += X_t[t] / (double) G[t].size();
            res += bipush_v_absorbed_random_walk(t, R_t, R_s);
        } else if (t == landmark) {
            // r(s, v) = (L_v^-1)ss
            bipush_v_absorbed_push(s, R_s, X_s);
            res += X_s[s] / (double) G[s].size();
            res += bipush_v_absorbed_random_walk(s, R_s, R_t);
        } else {
            // r(s, t)
            bipush_v_absorbed_push(s, R_s, X_s);
            bipush_v_absorbed_push(t, R_t, X_t);

            res += (X_s[s] - X_t[s]) / (double) G[s].size() + (X_t[t] - X_s[t]) / (double) G[t].size();
            res += bipush_v_absorbed_random_walk(s, R_s, R_t);
            res += bipush_v_absorbed_random_walk(t, R_t, R_s);
        }
        return res;
    }

    size_t getMemoryUsage() {
        size_t res = 0;
        return res;
    }
};
