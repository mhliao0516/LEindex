## Environment
- Ubuntu 22.04
- GCC 11.2.0

## Compile
- make

## Build Graph
Divide original graph data into initial graph and update edges.
Generate landmark nodes according to degree in initial graph.
Generate 5 workloads with different proportion of updates and queries.
```sh
preprocess -d <dataset_path> -lm <numbers_of_landmarks> -ap <proportion_of_add_edges> -wl <workload_size>
```

Example:
```sh
# Select 90% of edges in original hepth graph to build initial graph.
# Generate 10 landmarks with maximum degree.
# Generate 5 workloads with 100 updates/queries, the proportion of queries vary from 0% to 100%.
./preprocess -d hepth -lm 10 -ap 0.1 -wl 100
```

## Run a workload
Run an algorithm to process the workload.
```
main -d <dataset_path> -a <algorithm_name> -q <workload_filename> [options]
```
Descriptions:
- algorithm_name: le, rw, bp
- options:
    - eps: relevant to the index size. (0.5 by default)
    - rmax: max residual in bipush query. (0.001 by default)
    - T: the number of random walks in bipush query. (100 by default)
    - lm: the number of landmarks. (10 by default)
    - gt: the filename of ground truth:
        - saving the ground truth when algorithm is bp(Bipush),
        - reading the ground truth and computing error otherwise.
    - me: whether compute space consumption of algorithm. 
    - static: whether resample index when edge updating. 
    - log: the filename log.
Example:
```sh
# generate ground truth of 'q50.txt' for graph 'hepth' by using Bipush and save GT in 'gt.txt'.
./main -d hepth -a bp -q q50.txt -gt gt.txt -rmax 1e-6 -T 10000
# use LEIndex to handle workload 'q50.txt' of graph 'hepth'.
# compute relative error by given ground truth and compute space consumption
./main -d hepth -a le -q q50.txt -gt gt.txt -me -eps 0.5 -rmax 1e-3 -T 100
# use RWIndex-R to handle workload q100.txt
./main -d hepth -a rw -q q100.txt -static
```

## Run experiment
```sh
sh exp.sh
```