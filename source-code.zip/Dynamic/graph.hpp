#ifndef GRAPH_HPP
#define GRAPH_HPP

#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <iomanip>
#include <cassert>
#include <random>
#include <algorithm>

using namespace std;
using Edge = pair<int, int>;

typedef int ll;

class Graph {
public:

    vector<vector<int>> adj;
    string graph_file;
    int n, m;

    Graph() {
    } 

    Graph(int n, int m) {
        this->n = n, this->m = m;
        adj.resize(n + 1);
    }

    Graph(string filename) {
        graph_file = filename;
        read_graph_undirect(filename);
    }

    bool add_edge(int u, int v) {
        if (adj.size() <= max(u, v)) {
            printf("Adj Init Error\n");
            return false;
        }
        if (find(adj[u].begin(), adj[u].end(), v) != adj[u].end()) {
            printf("Add Edge (%d, %d) Error!\n", u, v);
            printf("Edge is already existed!\n");
            return false;
        }

        adj[u].push_back(v);
        adj[v].push_back(u);

        return true;
    }

    bool del_edge(int u, int v)
    {
        auto it_u = find(adj[u].begin(), adj[u].end(), v);
        auto it_v = find(adj[v].begin(), adj[v].end(), u);

        if (it_u == adj[u].end() || it_v == adj[v].end())
        {
            printf("Del Edge (%d, %d) Error!\n", u, v);
            printf("Edge is not existed!\n");
            return false;
        }

        adj[u].erase(it_u);
        adj[v].erase(it_v);
        return true;
    }

    bool del_vertex(int v) {
        if (adj[v].size() == 0) {
            cout << v << " has no edges" << endl;
            return false;
        }
        
        for (int ne : adj[v]) {
            auto it = find(adj[ne].begin(), adj[ne].end(), v);
            adj[ne].erase(it);
        }
        adj[v].clear();

        return true;
    }

    void read_graph_undirect(string filename) {
        FILE *fin = fopen(filename.c_str(), "r");
        //printf("Start Reading...\n");
        if (fin == NULL) {
            printf("Reading Graph Failed\n");
            assert(true);
        }
        int t1, t2;
        if (fscanf(fin, "%d%d", &t1, &t2) == EOF) {
            printf("Read Error!!!\n");
            return;
        }
        n = t1;
        m = t2;
        adj = vector<vector<int>>(n + 1, vector<int>());

        while (fscanf(fin, "%d%d", &t1, &t2) != EOF) {
            adj[t1].push_back(t2);
            adj[t2].push_back(t1);
        }
        fclose(fin);

        //printf("Read Graph %s Successed!\n", filename.c_str());
        return;
    }

};

void read_edge_list(string filename, vector<Edge> &edges) {
    FILE *fin = fopen(filename.c_str(), "r");
    int u, v;
    while (fscanf(fin, "%d%d", &u, &v) != EOF) {
        edges.emplace_back(u, v);
    }

    fclose(fin);
    return;
} 


#endif