#include "methods.hpp"
#include "workloads.hpp"
#include <time.h>

#define STR_EQUAL(s1, s2) strcmp(s1, s2) == 0
#define ALG_LE  0
#define ALG_RW  1
#define ALG_ST  2
#define ALG_BP  3


vector<int> read_landmarks(string filename) {
    FILE *fin = fopen(filename.c_str(), "r");
    int t;
    vector<int> tmls;
    while (fscanf(fin, "%d", &t) != EOF) 
        tmls.push_back(t);

    return tmls;
}

void read_workload(string workload_file, vector<tuple<char, int, int>> &wl) {
    ifstream if_wl(workload_file);
    char type;
    int wl_siz, u, v;
    
    wl.clear();

    if_wl >> wl_siz;
    while (wl_siz--) {
        if_wl >> type >> u >> v;
        wl.push_back(make_tuple(type, u, v));
    }
    if_wl.close();
    std::cout << "Workload Reading Finish" << endl;
    return;
}

int main(int argc, char **argv) {
    string datafolder = "./datasets/", dataset_name = "hepth", log_name = "log.txt", alg_name = "Lewalk Index", workload_name = "q50.txt", gt_name = "gt.txt";
    string graph_file, gt_file, workload_file, landmark_file, log_file;
    int alg_flag = ALG_LE, err_flag = 0, memory_usage_flag = 0, graph_memory_usage_flag = 0, 
        static_flag = 0, time_complexity_flag = 0, time_complexity_build_flag = 0, ppr_flag = 0;
    int T = 100, lm = 10, tc_siz = 1000, tcb_siz = 100;
    double epsilon = 0.5, rmax = 1e-3, delta = 10, alpha = 0.2;
    ofstream of_log, of_gt;
    clock_t st, ed, idx_build_t = 0;
    vector<tuple<char, int, int>> workloads;
    vector<double> res, gt;
    vector<int> landmarks;
    srand(time(0));

    for (int i = 1; i < argc; i++) {
        if (STR_EQUAL(argv[i], "-d")) {
            dataset_name = argv[++i];   // Dataset folder name
        } else if (STR_EQUAL(argv[i], "-a")) {
            alg_name = argv[++i];
            if (STR_EQUAL(argv[i], "le"))   alg_flag = ALG_LE;
            else if (STR_EQUAL(argv[i], "rw")) alg_flag = ALG_RW;
            else if (STR_EQUAL(argv[i], "st")) alg_flag = ALG_ST;
            else if (STR_EQUAL(argv[i], "bp")) alg_flag = ALG_BP;
            else assert(false);
        } else if (STR_EQUAL(argv[i], "-log")) {
            log_name = argv[++i];            // log filename
        } else if (STR_EQUAL(argv[i], "-q")) {
            workload_name = argv[++i];  // workload filename
        } else if (STR_EQUAL(argv[i], "-gt")) {
            gt_name = argv[++i];        // groundtruth filename
            err_flag = 1;
        } else if (STR_EQUAL(argv[i], "-eps")) {
            epsilon = atof(argv[++i]);  // Set Epsilon (Default 0.5)
        } else if (STR_EQUAL(argv[i], "-rm")) {
            rmax = atof(argv[++i]);     // Set r_max for bipush (Default 1e-3)
        } else if (STR_EQUAL(argv[i], "-T")) {
            T = atoi(argv[++i]);        // Set T for bipush (Default 100)
        } else if (STR_EQUAL(argv[i], "-lm")) {
            lm = atoi(argv[++i]);        // Set landmarks size (Default 10)
        } else if (STR_EQUAL(argv[i], "-dt")) {
            delta = atof(argv[++i]);    // Set delta for StSol (Default 10)
        } else if (STR_EQUAL(argv[i], "-me")) {
            memory_usage_flag = 1;      // Show Memory Usage
        } else if (STR_EQUAL(argv[i], "-gme")) {
            graph_memory_usage_flag = 1;      // Show Graph Memory Usage
        } else if (STR_EQUAL(argv[i], "-static")) {
            static_flag = 1;            // Use Static Algorithm
        } else if (STR_EQUAL(argv[i], "-ppr")) {
            ppr_flag = 1;               // Compute Personalized PageRank
        } else if (STR_EQUAL(argv[i], "-alpha")) {
            alpha = atof(argv[++i]);    // Set Alpha for PPR (Default 0.2)
        } else if (STR_EQUAL(argv[i], "-tc")) {
            time_complexity_flag = 1;      // Compute Time Complexity
            tc_siz = atoi(argv[++i]);
        } else if (STR_EQUAL(argv[i], "-tcb")) {
            time_complexity_build_flag = 1;   // Compute Time Complexity
            tcb_siz = atoi(argv[++i]);
        } else assert(false);
    }

    std::cout << "Dataset: " << dataset_name << endl;

    datafolder = datafolder + dataset_name + "/";
    log_file = datafolder + log_name, gt_file = datafolder + gt_name, workload_file = datafolder + workload_name;
    graph_file = datafolder + "graph.txt", landmark_file = datafolder + "landmark.txt";
    of_log.open(log_file, ios::app);
    
    // Read Graph & landmarks
    Graph g = Graph(graph_file);
    // Graph Memory
    if (graph_memory_usage_flag) {
        size_t memory_use = g.getMemoryUsage();
        of_log << "Graph: " << dataset_name << endl;
        of_log << "Memory Usage: " << (double) memory_use / 1024 / 1024 << " MB" << endl;
        return 0;
    }

    Solver *sol;
    // Read landmarks & decide landmarks size (Defautl 10 landmarks)
    landmarks = read_landmarks(landmark_file);
    if (lm < landmarks.size()) {
        landmarks = vector<int>(landmarks.begin(), landmarks.begin()+lm);
    }
    
    // Handle Workloads
    read_workload(workload_file, workloads);

    // Compute Time Complexity
    if (time_complexity_flag) {
        // Algorithm
        if (alg_flag == ALG_LE) {   // LEIndex
            LeSol ls = LeSol(g, landmarks, epsilon, rmax, T);
            ls.init();
            ls.compute_time_complexity(of_log, tc_siz);
        } else if (alg_flag == ALG_RW) {    // RWIndex
            RWTimeComplexity rwtc = RWTimeComplexity(g, landmarks, epsilon);
            rwtc.init(tc_siz);
            rwtc.compute_time_complexity(of_log);
        } else {
            cout << "This algorithm does not support computing Time Complexity" << endl;
        }
        return 0;
    } else if (time_complexity_build_flag) {
        if (alg_flag == ALG_LE) {
            LeSol ls = LeSol(g, landmarks, epsilon, rmax, T);
            double tcb = ls.compute_building_time_complexity(tcb_siz);
            of_log << "--------------------------------------------------------" << endl;
            of_log << "Average Building Time Complexity of LEIndex: " << tcb << endl;
            of_log << "--------------------------------------------------------" << endl;
        } else if (alg_flag == ALG_RW) {
            RWTimeComplexity rwtc = RWTimeComplexity(g, landmarks, epsilon);
            double tcb = rwtc.compute_build_time_complexity(tcb_siz);
            of_log << "--------------------------------------------------------" << endl;
            of_log << "Average Building Time Complexity of Random Walk: " << tcb << endl;
            of_log << "--------------------------------------------------------" << endl;
        } else {
            cout << "This algorithm does not support computing Time Complexity" << endl;
        }

        return 0;
    }

    // PageRank
    if (ppr_flag) {
        LeSolPPR sol(g, epsilon, alpha);
        sol.init(); 
        of_log << "-----------------------------------" << endl;
        of_log << "Graph: " << dataset_name << endl;
        of_log << "Workload: " << workload_name << endl;
        of_log << "eps: " << epsilon << ", alpha: " << alpha << endl;
        of_log << "rmax: " << sol.rmax << endl;
        of_log << "Index Size: " << sol.T << endl;

        handle_workload_ppr(&sol, workloads, of_log);

        return 0;
    }


    // Output Basic Information
    of_log << "-----------------------------------" << endl;
    of_log << "Graph: " << dataset_name << endl;
    of_log << "Algorithm: " << alg_name << (static_flag ? "(static)" : "") << endl;
    of_log << "Workload: " << workload_name << endl;
    of_log << "eps: " << epsilon << endl;
        
    // Index Size / Landmarks Size / Bipush Params
    if (alg_flag == ALG_LE || alg_flag == ALG_RW) {
        of_log << "Landmark Size: " << landmarks.size() << endl;
        of_log << "r_max: " << rmax << ", T: " << T << endl;
    } else if (alg_flag == ALG_ST) {
        of_log << "Delta: " << delta << endl;
    }

    if (alg_flag == ALG_LE) {
        sol = new LeSol(g, landmarks, epsilon, rmax, T);
    } else if (alg_flag == ALG_RW) {
        sol = new RwSol(g, landmarks, epsilon, rmax, T);
    } else if (alg_flag == ALG_ST) {
        sol = new StSol(g, landmarks[0], epsilon, delta);
    } else if (alg_flag == ALG_BP) {
        sol = new Bipush(g, landmarks[0], rmax, T);
    } else assert(false);

    

    // init
    st = clock();
    int IdxSiz = sol->init();
    ed = clock();

    of_log << "Index Size: " << IdxSiz << endl;
    of_log << "Index Building Time: " << (double) (ed - st) / CLOCKS_PER_SEC << " s" << endl;
    
    // Memory Usage
    if (memory_usage_flag) {
        size_t memory_use = sol->getMemoryUsage();
        of_log << "Memory Usage: " << (double) memory_use / 1024 / 1024 << " MB" << endl;
    }
    
    // vector<tuple<int, int, double>> res = handle_workload(sol, workloads);
    if (!static_flag) {
        res = handle_workload(sol, workloads, of_log);
    } else {
        res = handel_workoad_static(sol, g, workloads, of_log);
    }

    // Compute Relative Error
    if (err_flag) {
        // if ALG = BP, save result
        if (alg_flag == ALG_BP) {
            // Save Ground Truth
            of_gt.open(gt_file, ios::out);
            for (auto r : res)
                of_gt << setprecision(16) << r << endl;

        } else if (res.size() == 50){
        // else compute rel error
            // Read Ground Truth
            ifstream if_gt(gt_file, ios::in);
            double gt_i, max_err = 0., total_err = 0.;
            for (int i = 0; i < res.size(); i++) {
                if_gt >> gt_i;
                gt.push_back(gt_i);
            }
            // compute relative error
            for (int i = 0; i < res.size(); i++) {
                max_err = max(max_err, abs(res[i] - gt[i]) / gt[i]);
                total_err += abs(res[i] - gt[i]) / gt[i];
            }
            
            total_err /= (double) res.size();
            of_log << "Average Relative Error: " << setprecision(10) << total_err << ", Max Relative Error: " << max_err << endl;
        }
    }
    
    delete(sol);
    of_log.close();
    return 0;
}