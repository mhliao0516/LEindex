#include "graph.hpp"
#include <functional>
#define STR_EQUAL(s1, s2) strcmp(s1, s2) == 0

#define DEGREE  0
#define DEPTH   1
#define PASS    2
#define HERTIC  3

std::string gen_graph_file, add_edge_file, del_edge_file, alg_name = "degree";
int alg_flag = DEGREE;

struct cmp {
    bool operator()(const pair<int, int>& p1, const pair<int, int>& p2) {
        return p1.second < p2.second;
    }
};

void build_bfs_tree(Graph &graph, vector<int> &bfs_next, int root) {
    int n = graph.n, visit_cnt;
    vector<vector<int>> &G = graph.adj;
    vector<bool> visit(n + 1,false);
    
    bfs_next = vector<int>(n + 1, 0);
    queue<int> q;

    q.push(root);
    visit[root] = true;
    visit_cnt = 1;

    while (!q.empty()) {
        int cur = q.front();
        q.pop();

        for (int ne : G[cur]) {
            if (!visit[ne]) {
                q.push(ne);
                bfs_next[ne] = cur;

                visit[ne] = true;
                visit_cnt++;
            }
        }
        if (visit_cnt == n) break;
    }

    return;
}

void lewalk_test(Graph &graph, vector<int> &tmls) {
    int n = graph.n, cur, vis_cnt = tmls.size();
    size_t cnt = 0;
    clock_t start, end;
    vector<vector<int>> &G = graph.adj;
    vector<bool> intree(n + 1, false);
    vector<int> next(n + 1, 0);

    for (int t : tmls) {
        intree[t] = true;
    }

    start = clock();

    for (int i = 1; i <= n; i++) {
        for (cur = i; !intree[cur]; cur = next[cur]) {
            next[cur] = G[cur][rand() % G[cur].size()];
            cnt++;
        }
        for (cur = i; !intree[cur]; cur = next[cur]) {
            intree[cur] = true;

            vis_cnt++;
        }
        if (vis_cnt == n) break;
    }
    end = clock();

    cout << "Total Pass: " << cnt << endl;
    cout << (double) (end - start) / CLOCKS_PER_SEC << " s" << endl;

    return;
}

int find_new_terminal_by_depth(Graph &graph, vector<int> &tmls) {
    int n = graph.n, d = 0, cur, vis_cnt = tmls.size();
    vector<vector<int>> &G = graph.adj, tree(n + 1);
    vector<bool> intree(n + 1, false), visit(n + 1, false);
    vector<int> next(n + 1, 0), dep(n + 1, 0);
    queue<int> q;

    for (int t : tmls) {
        intree[t] = true;
        
        q.push(t);
        visit[t] = true;
    }

    for (int i = 1; i <= n; i++) {
        for (cur = i; !intree[cur]; cur = next[cur]) {
            next[cur] = G[cur][rand() % G[cur].size()];
        }
        for (cur = i; !intree[cur]; cur = next[cur]) {
            intree[cur] = true;

            tree[cur].push_back(next[cur]);
            tree[next[cur]].push_back(cur);

            vis_cnt++;
        }
        if (vis_cnt == n) break;
    }

    vis_cnt = tmls.size();
    while(!q.empty()) {
        cur = q.front();
        q.pop();

        for (int ne : tree[cur]) {
            if (!visit[ne]) {
                visit[ne] = true;
                dep[ne] = dep[cur] + 1;
                q.push(ne);
                vis_cnt++;
            }
        }
        if (vis_cnt == n) break;
    }


    int max_dep = 0, new_tml;
    for (int i = 1; i <= n; i++) {
        if (dep[i] > max_dep) {
            max_dep = dep[i];
            new_tml = i;
        }
    }
    for (cur = new_tml; dep[cur] > (int)(max_dep * 0.66); cur = next[cur]) {
        ;
    }
    new_tml = cur;

    return new_tml;
}

int find_new_terminal_by_pass(Graph &graph, vector<int> &tmls) {
    int n = graph.n, d = 0, cur, vis_cnt = tmls.size();
    vector<vector<int>> &G = graph.adj;
    vector<bool> intree(n + 1, false);
    vector<int> next(n + 1, 0), pass(n + 1, 0);

    for (int t : tmls) {
        intree[t] = true;
    }

    for (int i = 1; i <= n; i++) {
        for (cur = i; !intree[cur]; cur = next[cur]) {
            next[cur] = G[cur][rand() % G[cur].size()];
            pass[cur]++;
        }
        for (cur = i; !intree[cur]; cur = next[cur]) {
            intree[cur] = true;

            vis_cnt++;
        }
        if (vis_cnt == n) break;
    }

    int max_pass = 0, new_tml;
    for (int i = 1; i <= n; i++) {
        if (pass[i] > max_pass) {
            max_pass = pass[i];
            new_tml = i;
        }
    }
    return new_tml;
}

int find_new_terminal_by_degree(Graph &graph, int last_tml, vector<int> &deg) {
    int n = graph.n;
    vector<vector<int>> &G = graph.adj;
    
    deg[last_tml] = 0;
    for (int ne : G[last_tml]) {
        deg[ne]--;
    }

    int max_deg = 0, new_tml;
    for (int i = 1; i <= n; i++) {
        if (deg[i] > max_deg) {
            max_deg = deg[i];
            new_tml = i;
        }
    }
    return new_tml;
}

int find_new_terminal_by_siz(Graph &graph, vector<int> &tmls) {
    int n = graph.n, cur, vis_cnt = tmls.size();
    vector<vector<int>> &G = graph.adj, tree(n + 1);
    vector<bool> intree(n + 1, false);
    vector<int> next(n + 1, 0), siz(n + 1, 0), dep(n + 1, 0);
    vector<ll> score(n + 1, 0);

    for (int t : tmls) {
        intree[t] = true;
    }

    for (int i = 1; i <= n; i++) {
        for (cur = i; !intree[cur]; cur = next[cur]) {
            next[cur] = G[cur][rand() % G[cur].size()];
        }
        for (cur = i; !intree[cur]; cur = next[cur]) {
            intree[cur] = true;

            tree[cur].push_back(next[cur]);
            tree[next[cur]].push_back(cur);
            
            vis_cnt++;
        }
        if (vis_cnt == n) break;
    }

    function<void(int, int)> dfs = [&](int cur, int fa) {
        dep[cur] = dep[fa] + 1;
        for (int ne : tree[cur]) {
            if (ne == fa) continue;
            dfs(ne, cur);
            siz[cur] += siz[ne];
        }
        siz[cur]++;
        score[cur] = siz[cur] * dep[cur] * G[cur].size();
    };
    for (int t : tmls) {
        dfs(t, 0);
    }

    int max_sc = 0, new_tml;
    for (int i = 1; i <= n; i++) {
        if (score[i] > max_sc && dep[i] != 1) {
            max_sc = score[i];
            new_tml = i;
        }
    }
    return new_tml;
}

vector<int> find_landmark(Graph &graph, int l = 100) {
    int n = graph.n, new_tml;
    vector<vector<int>> &G = graph.adj;
    vector<int> tmls, deg(n + 1, 0);
    
    int max_deg = 0, root;
    for (int i = 1; i <= n; i++) {
        deg[i] = G[i].size();
        if (G[i].size() > max_deg) {
            max_deg = G[i].size();
            root = i;
        }
    }
    tmls.push_back(root);
    l--;

    while (l--) {
        if (alg_flag == DEGREE) {
            new_tml = find_new_terminal_by_degree(graph, tmls.back(), deg);
        } else if (alg_flag == DEPTH) {
            new_tml = find_new_terminal_by_depth(graph, tmls);
        } else if (alg_flag == PASS) {
            new_tml = find_new_terminal_by_pass(graph, tmls);
        } else if (alg_flag == HERTIC) {
            new_tml = find_new_terminal_by_siz(graph, tmls);
        } else assert(true);
        //int new_tml = find_new_terminal_by_degree(graph, tmls.back(), deg);
        tmls.push_back(new_tml);
    }
    cout << "Alg: " << alg_name << endl;
    lewalk_test(graph, tmls);

    return tmls;
}

void divide_graph(Graph &graph, vector<Edge>&add_edges, vector<Edge> &del_edges, double add_proportion = 0.1, double del_proportion = 0.1)
{
    int n = graph.n, m, p = 0, u, v;
    vector<vector<int>> &G = graph.adj;
    vector<Edge> edges;
    vector<int> bfs_next;

    for (int i = 1; i <= n; i++) {
        for (int ne : G[i]) {
            if (ne > i) {
                edges.emplace_back(i, ne);
            }
        }
    }
    m = edges.size();
    int add_num = (int) (edges.size() * add_proportion);
    int del_num = (int) (edges.size() * del_proportion);
    shuffle(edges.begin(), edges.end(), default_random_engine(time(NULL)));

    build_bfs_tree(graph, bfs_next, rand() % n + 1);

    for (int i = 0; i < add_num; i++) {
        if (p >= m) {
            cout << "Divide Graph Error!! Decrease Add/Del Edge Num." << endl;
            return;
        }
        while (p < m) {
            u = edges[p].first, v = edges[p].second;
            p++;
            if (bfs_next[u] != v && bfs_next[v] != u) {
                break;
            }
        }
        
        add_edges.emplace_back(u, v);
        graph.del_edge(u, v);
    }

    for (int i = 0; i < del_num; i++) {
        if (p >= m) {
            cout << "Divide Graph Error!! Decrease Add/Del Edge Num." << endl;
            return;
        }

        while (p < m) {
            u = edges[p].first, v = edges[p].second;
            p++;
            if (bfs_next[u] != v && bfs_next[v] != u) {
                break;
            }
        }
        
        del_edges.emplace_back(u, v);
    }
    // Save Graph
    ofstream of_graph, of_add_edge, of_del_edge;
    
    of_graph.open(gen_graph_file);
    of_graph << n << " " << m - add_num << endl;
    for (int i = 1; i <= n; i++) {
        for (int ne : G[i]) {
            if (ne > i) of_graph << i << " " << ne << endl;
        }
    }
    of_graph.close();

    /* // Save Add Edges
    of_add_edge.open(add_edge_file);
    for (auto [u, v] : add_edges) {
        of_add_edge << u << " " << v << endl;
    }
    of_add_edge.close(); */

    /* Save Del Edges
    of_del_edge.open(del_edge_file);
    for (auto [u, v] : del_edges) {
        of_del_edge << u << " " << v << endl;
    }
    of_del_edge.close();
    */
    return;
}

void divide_temporal_graph(Graph &g, string filename, vector<Edge>&add_edges, vector<Edge> &del_edges, double add_prop = 0.1) {
    int n, m, add_siz;
    vector<tuple<ll, int, int>> edges; //= read_temporal_edge_list(filename, n, m);
    add_siz = m * add_prop;
    g = Graph(n, m);

    sort(edges.begin(), edges.end());

    for (int i = m - add_siz; i < m; i++) {
        add_edges.emplace_back(get<1>(edges[i]), get<2>(edges[i]));
    }

    for (int i = 0; i < m - add_siz; i++) {
        int u = get<1>(edges[i]), v = get<2>(edges[i]);
        g.add_edge(u, v);
    }

    ofstream of_graph(gen_graph_file);
    of_graph << n << " " << m - add_siz << endl;
    for (int i = 1; i <= n; i++) {
        for (int ne : g.adj[i]) {
            if (ne > i) of_graph << i << " " << ne << endl;
        }
    }
    of_graph.close();
}

void gen_landmark_set(Graph &graph, string filename, int l = 100) {
    int n = graph.n, root;
    vector<vector<int>> &G = graph.adj;
    vector<int> landmark_set;
    
    landmark_set = find_landmark(graph, l);

    ofstream outFile;
    outFile.open(filename);

    for (int i = 0; i < l; i++) {
        outFile << landmark_set[i] << endl;
    }

    outFile.close();
    return;
}

void gen_workload(int n, vector<Edge> add_edges, vector<Edge> del_edges, string workload_file, int add_size, int del_size, int query_size) {
    vector<tuple<char, int, int>> workload;
    shuffle(add_edges.begin(), add_edges.end(), default_random_engine(time(NULL)));
    shuffle(del_edges.begin(), del_edges.end(), default_random_engine(time(NULL)));

    while (add_size--) {
        auto [u, v] = add_edges.back();
        add_edges.pop_back();
        workload.push_back(make_tuple('I', u, v));
    }
    while (del_size--) {
        auto [u, v] = del_edges.back();
        del_edges.pop_back();
        workload.push_back(make_tuple('D', u, v));
    }
    while (query_size--) {
        int u = rand() % n + 1, v = rand() % n + 1;
        workload.push_back(make_tuple('Q', u, v));
    }

    shuffle(workload.begin(), workload.end(), default_random_engine(time(NULL)));
    
    ofstream of_workload(workload_file);
    of_workload << workload.size() << endl;
    for (const auto& [type, u, v] : workload) {
        of_workload << type << " " << u << " " << v << endl;
    }
    of_workload.close();

    return;
}

void gen_workloads(int n, vector<Edge> &add_edges, vector<Edge> &del_edges, string folder_name, int workload_size = 30)
{
    vector<double> query_prop = {0., 0.25, 0.5, 0.75, 1.};
    int add_num, del_num, query_num;

    for (double p : query_prop) {
        query_num = workload_size * p;
        add_num = (workload_size - query_num) / 2;
        del_num = workload_size - query_num - add_num;
        string file_name = folder_name+"q" + to_string(query_num) + ".txt";
        gen_workload(n, add_edges, del_edges, file_name, add_num, del_num, query_num);
    }

    return;
}

int main(int argc, char **argv) {
    string folder = "./datasets/", data_name = "orkut";
    int landmark_siz = 100, workload_siz = 100;
    double add_porp = 0.1;
    bool divide_flag = true;
    for (int i = 1; i < argc; i++) {
        if (STR_EQUAL(argv[i], "-d")) {
            // 输入图数据路径
            data_name = argv[++i];   
        } else if (STR_EQUAL(argv[i], "-lm")) {
            // landmark大小
            landmark_siz = atoi(argv[++i]);  
        } else if (STR_EQUAL(argv[i], "-wl")) {
            // workload大小
            workload_siz = atoi(argv[++i]);  
        } else if (STR_EQUAL(argv[i], "-ap")) {
            add_porp = atof(argv[++i]);
        } else if (STR_EQUAL(argv[i], "-al")) {
            alg_name = argv[++i];
            if (STR_EQUAL(argv[i], "dg"))   alg_flag = DEGREE;
            else if (STR_EQUAL(argv[i], "dp")) alg_flag = DEPTH;
            else if (STR_EQUAL(argv[i], "ps")) alg_flag = PASS;
            else if (STR_EQUAL(argv[i], "he")) alg_flag = HERTIC;
            else assert(false);
        } else if (STR_EQUAL(argv[i], "-nd")) {
            divide_flag = false;
        } else assert(false);
    }

    folder = folder + data_name + "/";
    // string org_graph_file = folder+"graph_org.txt", landmark_file=folder+"landmark.txt";
    string org_graph_file = folder+"graph_org.txt", landmark_file=folder+"landmark.txt";
    
    gen_graph_file = folder + "graph.txt", add_edge_file = folder + "add_edges.txt", del_edge_file = folder + "del_edges.txt"; 
    
    Graph g;
    vector<Edge> add_edges, del_edges;

    if (divide_flag) {
        g = Graph(org_graph_file);
        divide_graph(g, add_edges, del_edges, add_porp);
    } else {
        g = Graph(gen_graph_file);
        read_edge_list(add_edge_file, add_edges);
        read_edge_list(del_edge_file, del_edges);
    }

    gen_landmark_set(g, landmark_file, landmark_siz);
    gen_workloads(g.n, add_edges, del_edges, folder, workload_siz);

    return 0;
}