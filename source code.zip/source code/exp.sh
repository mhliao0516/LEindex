#!/bin/sh
Q_arr=(0 25 50 75 100)
alg_arr=(le rw)
g_arr=(hepth) 

make
# preprocess
./preprocess -d hepth -lm 10 -ap 0.1 -wl 100
# gt
./main -d hepth -a bp -q q50.txt -gt gt.txt -rmax 1e-6 -T 10000
# LEIndex & RWIndex
for g in "${g_arr[@]}"
do
    for alg in "${alg_arr[@]}"
    do
        for Q in "${Q_arr[@]}"
        do
            echo ./main -d ${g} -a ${alg} -q q${Q}.txt
            ./main -d ${g} -a ${alg} -q q${Q}.txt
        done
    done
done
# Resample Algorithm
for g in "${g_arr[@]}"
do
    for alg in "${alg_arr[@]}"
    do
        for Q in "${Q_arr[@]}"
        do
            ./main -d ${g} -a ${alg} -q q${Q}.txt -static
        done
    done
done