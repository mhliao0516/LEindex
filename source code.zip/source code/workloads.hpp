#include "methods.hpp"

vector<double> handle_workload(Solver* sol, vector<tuple<char, int, int>> &wl, ofstream& of_log) {
    vector<double> res;
    clock_t st, ed, ins_t = 0, del_t = 0, qry_t = 0;
    int ins_cnt = 0, del_cnt = 0, qry_cnt = 0;
    double r;

    for (auto [type, u, v] : wl) {
        if(type == 'I') {
            st = clock();
            sol->add_edge_update(u, v);
            ed = clock();

            printf("Add Edge (%d, %d), using %lf s.\n", u, v, (double)(ed - st)/CLOCKS_PER_SEC);
            ins_cnt++;
            ins_t += ed - st;
        } else if (type == 'D') {
            st = clock();
            sol->del_edge_update(u, v);
            ed = clock();

            printf("Del Edge (%d, %d), using %lf s.\n", u, v, (double)(ed - st)/CLOCKS_PER_SEC);
            del_cnt ++;
            del_t += ed - st;
        } else if (type == 'Q') {
            st = clock();
            r = sol->single_pair_resistance_query(u, v);
            ed = clock();

            res.push_back(r);
            qry_cnt++;
            qry_t += ed - st;

            printf("r(%d, %d) = %lf, using %lf s.\n", u, v, r, (double)(ed - st)/CLOCKS_PER_SEC);
        }
    }

    of_log << "Insertion Num: " << ins_cnt 
    << ", Total Usage Time: " << (double)ins_t / CLOCKS_PER_SEC << " s, " 
    << "Average Usage Time: " << (double)ins_t / ins_cnt / CLOCKS_PER_SEC << " s." << endl;
    of_log << "Deletion Num: " << del_cnt 
    << ", Total Usage Time: " << (double)del_t / CLOCKS_PER_SEC << " s, " 
    << "Average Usage Time: " << (double)del_t / del_cnt / CLOCKS_PER_SEC << " s." << endl;
    of_log << "Query Num: " << qry_cnt 
    << ", Total Usage Time: " << (double)qry_t / CLOCKS_PER_SEC << " s, " 
    << "Average Usage Time: " << (double)qry_t / qry_cnt / CLOCKS_PER_SEC << " s." << endl;
    of_log << "Total Time: " << (double) (ins_t + del_t + qry_t) / CLOCKS_PER_SEC << " s." << endl;
    return res;
}

vector<double> handel_workoad_static(Solver* sol, Graph& graph, vector<tuple<char, int, int>> &wl, ofstream& of_log) {
    vector<double> res;
    clock_t st, ed, ins_t = 0, del_t = 0, qry_t = 0;
    int idx_siz, ins_cnt = 0, del_cnt = 0, qry_cnt = 0;
    double r;

    for (auto [type, u, v] : wl) {
        if(type == 'I') {
            st = clock();
            graph.add_edge(u, v);
            idx_siz = sol->init();
            ed = clock();

            ins_cnt++;
            ins_t += ed - st;
        } else if (type == 'D') {
            st = clock();
            graph.del_edge(u, v);
            idx_siz = sol->init();
            ed = clock();

            del_cnt ++;
            del_t += ed - st;
        } else if (type == 'Q') {
            st = clock();
            r = sol->single_pair_resistance_query(u, v);
            ed = clock();

            res.push_back(r);
            qry_cnt++;
            qry_t += ed - st;
            printf("r(%d, %d) = %lf\n", u, v, r);
        }
    }
    of_log << "Index Size: " << idx_siz << endl;
    of_log << "Insertion Num: " << ins_cnt 
    << ", Total Usage Time: " << (double)ins_t / CLOCKS_PER_SEC << " s, " 
    << "Average Usage Time: " << (double)ins_t / ins_cnt / CLOCKS_PER_SEC << " s." << endl;
    of_log << "Deletion Num: " << del_cnt 
    << ", Total Usage Time: " << (double)del_t / CLOCKS_PER_SEC << " s, " 
    << "Average Usage Time: " << (double)del_t / del_cnt / CLOCKS_PER_SEC << " s." << endl;
    of_log << "Query Num: " << qry_cnt 
    << ", Total Usage Time: " << (double)qry_t / CLOCKS_PER_SEC << " s, " 
    << "Average Usage Time: " << (double)qry_t / qry_cnt / CLOCKS_PER_SEC << " s." << endl;
    of_log << "Total Time: " << (double) (ins_t + del_t + qry_t) / CLOCKS_PER_SEC << " s." << endl;
    return res;
}

vector<double> handle_workload_ppr(LeSolPPR* sol, vector<tuple<char, int, int>> &wl, ofstream& of_log) {
    vector<double> res;
    double ins_t = 0., del_t = 0., qry_t = 0.;
    int ins_cnt = 0, del_cnt = 0, qry_cnt = 0;
    chrono::time_point<std::chrono::steady_clock> st, ed;
    double r;

    for (auto [type, u, v] : wl) {
        if(type == 'I') {
            st = chrono::steady_clock::now();
            sol->add_edge_update(u, v);
            ed = chrono::steady_clock::now();

            printf("Add Edge (%d, %d), using %lf s.\n", u, v, chrono::duration<double>(ed - st).count());
            ins_cnt++;
            ins_t += chrono::duration<double>(ed - st).count();
        } else if (type == 'D') {
            st = chrono::steady_clock::now();
            sol->del_edge_update(u, v);
            ed = chrono::steady_clock::now();

            printf("Del Edge (%d, %d), using %lf s.\n", u, v, chrono::duration<double>(ed - st).count());
            del_cnt ++;
            del_t += chrono::duration<double>(ed - st).count();
        } else if (type == 'Q') {
            st = chrono::steady_clock::now();
            sol->single_source_ppr_query(u);
            ed = chrono::steady_clock::now();

            res.push_back(r);

            qry_cnt++;
            qry_t += chrono::duration<double>(ed - st).count();
            printf("single source query %d, using %lf s.\n", u, chrono::duration<double>(ed - st).count());
        }
    }

    of_log << "Insertion Num: " << ins_cnt 
    << ", Total Usage Time: " << (double)ins_t<< " s, " 
    << "Average Usage Time: " << (double)ins_t / ins_cnt<< " s." << endl;
    of_log << "Deletion Num: " << del_cnt 
    << ", Total Usage Time: " << (double)del_t<< " s, " 
    << "Average Usage Time: " << (double)del_t / del_cnt << " s." << endl;
    of_log << "Query Num: " << qry_cnt 
    << ", Total Usage Time: " << (double)qry_t<< " s, " 
    << "Average Usage Time: " << (double)qry_t / qry_cnt<< " s." << endl;
    of_log << "Total Time: " << (double) (ins_t + del_t + qry_t)<< " s." << endl;
    return res;
}